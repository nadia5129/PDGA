<?php
echo "<h1>Hello from PHP! </h1>";
?>